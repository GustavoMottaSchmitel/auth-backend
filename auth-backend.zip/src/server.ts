import 'dotenv/config';
import fastify from 'fastify';
import cors from '@fastify/cors';
import { authRoutes } from './modules/auth/auth.routes.js';

const server = fastify({ logger: true });

// Register CORS
server.register(cors, {
  origin: '*', // For dev mode, accept all. In prod, lock this down.
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
});

// Register Routes
server.register(authRoutes, { prefix: '/auth' });

// Health check
server.get('/health', async () => {
  return { status: 'ok', service: 'auth-backend' };
});

const start = async () => {
  try {
    const port = Number(process.env.PORT) || 4000;
    await server.listen({ port, host: '0.0.0.0' });
    console.log(`Auth Backend running on http://localhost:${port}`);
  } catch (err) {
    server.log.error(err);
    process.exit(1);
  }
};

start();
